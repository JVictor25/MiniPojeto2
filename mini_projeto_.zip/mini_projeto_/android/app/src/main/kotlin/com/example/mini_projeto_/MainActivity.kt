package com.example.mini_projeto_

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
